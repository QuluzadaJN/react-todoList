import React from 'react';
import './App.css';
import FormTodo from './components/TodoComponent/FormTodo';
import Todo from './components/TodoComponent/Todo';
import CompletedTasks from './components/TodoComponent/CompletedTasks';

function App() {
  const [value, setValue] = React.useState("");

  const [completedTasks, setCompleted] = React.useState([
    { text: "Learn React" }
  ]);
  const [todos, setTodos] = React.useState([
    {
      text: "Learn about React"
    },
    {
      text: "Meet friend for lunch"
    },
    {
      text: "Build really cool todo app"
    }
  ]);

  return (
    <div className="app">
      <div className="container">
        <FormTodo
          // addTodo={addTodo}
          value={value}
          setValue={setValue}
          todos={todos}
          setTodos={setTodos}
        />
        <div>
          {todos.map((todo, index) => (
            <div>
              <div>
                <Todo
                  key={index}
                  index={index}
                  todo={todo}
                  todos={todos}
                  setTodos={setTodos}
                  completedTasks={completedTasks}
                  setCompleted={setCompleted}
                />
              </div>
            </div>
          ))}
        </div>
        <hr className="breakForCompleted" />
        {completedTasks.map((completedTask) => (
          <div>
            <CompletedTasks completedTask={completedTask} />
          </div>
        ))}
      </div>
    </div>
  );
}

export default App;
