import React from 'react';

const Todo = ({ todo, index, todos, setTodos, completedTasks, setCompleted }) => {

    const markTodo = index => {
        const newTodos = [...todos];
        const newCompletedTasks = [...completedTasks, { text: newTodos[index].text }]
        setCompleted(newCompletedTasks);
        newTodos.splice(index, 1);
        setTodos(newTodos);
    };

    const removeTodo = index => {
        const newTodos = [...todos];
        newTodos.splice(index, 1);
        setTodos(newTodos);
    };

    return (
        <div className="todo">
            <span>{todo.text}</span>
            <div>
                <button className="btn-todo outline-success" onClick={() => markTodo(index)}>✓</button>{' '}
                <button className="btn-todo outline-danger" onClick={() => removeTodo(index)}>✕</button>
            </div>
        </div>
    );
}

export default Todo;