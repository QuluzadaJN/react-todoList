import React from 'react';

const FormTodo = ({ value, setValue, todos, setTodos }) => {

    const handleSubmit = e => {
        e.preventDefault();
        if (!value) return;
        addTodo(value);
        setValue("");
    };

    const addTodo = text => {
        const newTodos = [...todos, { text }];
        setTodos(newTodos);
    };

    return (
        <form className="form-todo" onSubmit={handleSubmit}>
            <div className="form-wrapper">
                <input type="text" className="input" value={value} onChange={e => setValue(e.target.value)} placeholder="Add a task here..." />
                <button type="submit" className="addTodo">
                    +
                </button>
            </div>
        </form>
    );
}

export default FormTodo;