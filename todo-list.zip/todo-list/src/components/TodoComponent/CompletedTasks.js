import React from 'react';

const CompletedTasks = ({ completedTask }) => {
    return (
        <div className="todo completedTask">
            <span>{completedTask.text}</span>
            <button className="btn-todo outline-success">✓</button>
        </div>
    )
}

export default CompletedTasks;